const discNameString = 'Sexton';

setTimeout(() => {
    console.log('Page should be loaded, checking on stock availability');

    const areSextonsAvailable = areDiscsAvailableForPlayer(discNameString);

    if (areSextonsAvailable) {

        // sending an alert to your browser
        Notification.requestPermission().then(() => {
            new Notification('Innova Tour Series Alert', {body: 'There are ' + discNameString + '\'s available! GET ON IT!', requireInteraction: true});
        }).catch((err) => { throw new Error(err); });

        // sending you to the page
        [].slice.call(document.getElementsByClassName('item')).filter((item) => { return item.children[0].innerText.indexOf(discNameString) != -1; })[0].children[0].children[0].click();
    } else {
        setTimeout(() => {
            console.log('They were not available this refresh so lets try again...');
            location.reload();
        }, 10000);
    }
}, 5000);

function areDiscsAvailableForPlayer(playerName) {
    return [].slice.call(document.getElementsByClassName('item')).filter((item) => { return item.children[0].innerText.indexOf(playerName) != -1; }).length > 0;
}
